document.addEventListener('keydown', function (e) {
  if (e.key === 'Tab') {
    document.body.classList.add('show-focus-outlines');
  }
});
