<?php
echo password_hash("superadmin123", PASSWORD_BCRYPT);